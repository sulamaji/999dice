python main.py
sleep 10
sh run.sh